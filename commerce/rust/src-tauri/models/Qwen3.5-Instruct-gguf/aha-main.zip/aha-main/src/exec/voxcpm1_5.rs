//! VoxCPM1.5 exec implementation for CLI `run` subcommand
//!
//! This module handles VoxCPM1.5 model inference for direct CLI execution.
//! Input/output parameter interpretation is handled here as per the design:
//! - Input can be text content or a file path (with `file://` prefix)
//! - Output can be a file path or will be auto-generated if not specified

use std::time::Instant;

use anyhow::{Ok, Result};

use crate::models::voxcpm::generate::VoxCPMGenerate;
use crate::{exec::ExecModel, utils::get_file_path};

pub struct VoxCPM1_5Exec;

impl ExecModel for VoxCPM1_5Exec {
    fn run(input: &[String], output: Option<&str>, weight_path: &str) -> Result<()> {
        let input_text = &input[0];
        let target_text = if input_text.starts_with("file://") {
            // let path = &input[7..];
            let path = get_file_path(input_text)?;
            std::fs::read_to_string(path)?
        } else {
            input_text.clone()
        };

        let i_start = Instant::now();
        let mut voxcpm_generate = VoxCPMGenerate::init(weight_path, None, None)?;
        let i_duration = i_start.elapsed();
        println!("Time elapsed in load model is: {:?}", i_duration);

        let i_start = Instant::now();
        let audio = voxcpm_generate.inference(
            target_text,
            Some("啥子小师叔，打狗还要看主人，你再要继续，我就是你的对手".to_string()), // todo args
            Some("file://./assets/audio/voice_01.wav".to_string()),                     // todo args
            2,
            4096,
            10,
            2.0,
            6.0,
        )?;
        let i_duration = i_start.elapsed();
        println!("Time elapsed in generate is: {:?}", i_duration);

        let output_path = if let Some(out) = output {
            out.to_string()
        } else {
            let timestamp = std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)?
                .as_secs();
            format!("voxcpm1_5_{}.wav", timestamp)
        };

        let sample_rate = voxcpm_generate.sample_rate();
        crate::utils::audio_utils::save_wav(&audio, &output_path, sample_rate as u32)?;

        println!("Output saved to: {}", output_path);

        Ok(())
    }
}
